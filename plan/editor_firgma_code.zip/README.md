
  # BaudBound

  This is a code bundle for BaudBound. The original project is available at https://www.figma.com/design/3WkyZ2KqAKgbe1pCiKWBzu/BaudBound.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  