# BaudBound Project Plan

BaudBound is a local-first visual scripting automation platform.

Users create scripts in a hosted or self-hosted web editor, export them as `.bbs` files, and manually import them into a cross-platform Rust runner. The runner validates, stores, and executes scripts locally.

`.bbs` means **BaudBound Script**.

---

## 1. Core Product Direction

### Main Idea

BaudBound has two separate parts:

1. **BaudBound Editor**
   - Hosted by the project or self-hosted by users with Docker.
   - Runs as a web app.
   - Used to visually create scripts.
   - Exports `.bbs` script packages.
   - Does not connect to runners.
   - Does not execute scripts.

2. **BaudBound Runner**
   - Rust-based runtime.
   - Imports `.bbs` script packages manually.
   - Validates packages and script logic.
   - Shows permissions, capabilities, and risk level.
   - Executes scripts locally.
   - Must support headless systems, background service mode, and desktop agent mode.
   - Must work cross-platform: Windows, Linux, and macOS.

### Core Rule

```text
Editor builds scripts.
Runner owns execution.
```

The editor should never be treated as trusted. The runner must validate every imported script, even if it was exported from the official hosted BaudBound Editor.

---

## 2. Terminology

Use these names consistently throughout the codebase, UI, docs, and APIs.

| Term | Meaning |
|---|---|
| BaudBound | The whole platform/app ecosystem |
| BaudBound Editor | The web-based visual script builder |
| BaudBound Runner | The Rust script runtime |
| Script | An automation built by the user |
| `.bbs` | BaudBound Script package file |
| Script Package | A `.bbs` file containing script metadata, program, permissions, capabilities, and assets |
| Installed Script | A script imported into a runner |
| Script Runtime | The runner execution engine |
| Capability | Something the current runner mode/platform can technically support |
| Permission | Something the script wants to do that may require user approval |
| Risk Level | Low, medium, high, or dangerous classification calculated by the runner |

Avoid the word **macro** in UI and user-facing docs.

---

## 3. High-Level Architecture

```text
┌──────────────────────────────┐
│ BaudBound Editor              │
│                              │
│ Hosted or self-hosted web app │
│ Visual programming editor     │
│ No runner connection          │
│ No execution                  │
└──────────────┬───────────────┘
               │
               │ Export .bbs
               ▼
┌──────────────────────────────┐
│ .bbs Script Package           │
│                              │
│ manifest.json                 │
│ program.json                  │
│ permissions.json              │
│ capabilities.json             │
│ README.md                     │
│ assets/                       │
└──────────────┬───────────────┘
               │
               │ Manual import
               ▼
┌──────────────────────────────┐
│ BaudBound Runner              │
│                              │
│ Rust runtime                  │
│ Headless-first                │
│ CLI-first                     │
│ Service/daemon capable        │
│ Optional desktop agent/tray   │
└──────────────────────────────┘
```

---

## 4. Security Model

### Main Assumption

Every imported `.bbs` file may be malicious, corrupted, broken, outdated, or manually edited.

The runner must never trust:

- The hosted editor.
- A self-hosted editor.
- Browser-side validation.
- Package-declared permissions.
- Package-declared capabilities.
- The package file name.
- Asset paths inside the package.
- Any script downloaded from the internet.

### Import Security Pipeline

When importing a `.bbs` package, the runner must do this:

```text
Open .bbs safely
  ↓
Validate zip/package structure
  ↓
Check required files exist
  ↓
Validate JSON schemas
  ↓
Check format version
  ↓
Check minimum runner version
  ↓
Validate program AST
  ↓
Validate all node/action/trigger types
  ↓
Validate all config values
  ↓
Recalculate required capabilities
  ↓
Recalculate permissions
  ↓
Calculate risk level
  ↓
Check platform and runner mode support
  ↓
Check global runner security settings
  ↓
Show import summary to user
  ↓
Import disabled or import enabled
```

### Important Default Security Rules

- No live editor-to-runner connection by default.
- No exposed local API by default.
- No account system required.
- No LAN pairing system required for MVP.
- Runner validates all imported scripts.
- Imported high-risk scripts are disabled by default.
- Shell commands are blocked by default.
- File deletion is blocked by default.
- Startup triggers require explicit approval.
- Network/webhook server is disabled by default.
- Any network service binds to `127.0.0.1` by default.
- Runner must prevent path traversal in `.bbs` files.
- Runner must not execute files from `assets/` directly.
- Dangerous actions require explicit user approval.
- Headless runners must reject desktop-only scripts when enabled.

---

## 5. `.bbs` Package Format

A `.bbs` file is a zip-based package with a custom extension.

Example file names:

```text
work-startup.bbs
server-health-check.bbs
discord-helper.bbs
backup-monitor.bbs
```

Internal structure:

```text
work-startup.bbs
├─ manifest.json
├─ program.json
├─ permissions.json
├─ capabilities.json
├─ README.md
└─ assets/
```

### 5.1 `manifest.json`

Contains human-readable and versioning metadata.

Example:

```json
{
  "format_version": 1,
  "script_language_version": 1,
  "id": "67df0f35-5646-4384-9299-7533cc053e07",
  "name": "Work Startup",
  "description": "Opens work apps and prepares the desktop.",
  "author": "local-user",
  "website": "https://example.com",
  "repository": "https://github.com/username/scriptname",
  "created_with": "BaudBound Editor 1.0.0",
  "created_at": "2026-07-01T20:00:00Z",
  "updated_at": "2026-07-01T20:00:00Z",
  "tags": ["work", "startup", "desktop"],
  "minimum_runner_version": "0.1.0"
}
```

Required fields:

- `format_version`
- `script_language_version`
- `id`
- `name`
- `created_with`
- `created_at`
- `minimum_runner_version`

Optional fields:

- `description`
- `author`
- `website`
- `repository`
- `updated_at`
- `tags`

### 5.2 `program.json`

Contains the actual script program.

This must be a structured program format, not raw JavaScript, Python, Lua, or shell.

Example:

```json
{
  "entry": {
    "trigger": {
      "type": "manual"
    },
    "program": {
      "type": "block",
      "steps": [
        {
          "type": "let",
          "name": "status",
          "value": {
            "type": "string",
            "value": "warning"
          }
        },
        {
          "type": "switch",
          "value": {
            "type": "variable",
            "name": "status"
          },
          "cases": [
            {
              "match": {
                "type": "string",
                "value": "ok"
              },
              "steps": [
                {
                  "type": "action",
                  "action": "log",
                  "config": {
                    "message": "Everything is okay."
                  }
                }
              ]
            },
            {
              "match": {
                "type": "string",
                "value": "warning"
              },
              "steps": [
                {
                  "type": "action",
                  "action": "show_notification",
                  "config": {
                    "title": "Warning",
                    "message": "Status is warning."
                  }
                }
              ]
            }
          ],
          "default": [
            {
              "type": "action",
              "action": "log",
              "config": {
                "message": "Unknown status."
              }
            }
          ]
        }
      ]
    }
  }
}
```

### 5.3 `permissions.json`

Contains permissions as declared by the editor.

The runner must recalculate permissions itself and compare the result.

Example:

```json
{
  "declared_permissions": [
    "show_notification",
    "log"
  ],
  "risk_level": "low"
}
```

If declared permissions do not match runner-calculated permissions, the runner should show a warning.

Example warning:

```text
The package-declared permissions do not match the runner-calculated permissions.
This script may have been modified.
```

### 5.4 `capabilities.json`

Contains capabilities required by the script.

The runner must recalculate required capabilities itself and compare the result.

Example desktop script:

```json
{
  "required_capabilities": [
    "trigger.hotkey",
    "action.keyboard",
    "action.mouse",
    "action.window",
    "action.clipboard"
  ]
}
```

Example headless script:

```json
{
  "required_capabilities": [
    "trigger.schedule",
    "action.http",
    "action.file",
    "action.log"
  ]
}
```

### 5.5 `README.md`

Optional human-readable documentation.

Example:

```md
# Work Startup

This script opens work apps, checks clipboard content, and shows a notification.

## Required permissions

- Open applications
- Keyboard control
- Clipboard read
```

### 5.6 `assets/`

Optional directory for non-executable supporting files.

Examples:

```text
assets/
├─ sounds/notify.wav
├─ icons/work.png
└─ templates/message.txt
```

Asset rules:

- Assets must stay inside the package sandbox.
- No path traversal allowed.
- Reject paths containing `..` traversal.
- Reject absolute paths inside package entries.
- Runner must not execute assets directly.
- Assets should only be used as data.

---

## 6. Script Language Design

BaudBound scripts are a visual programming language represented as structured JSON.

The editor shows a node/block UI, but the exported package contains a clean AST-like program.

### 6.1 Core Script Concepts

A script contains:

- Trigger
- Program block
- Variables
- Expressions
- Actions
- Control flow
- Permissions
- Capabilities
- Logs

### 6.2 Data Types

MVP data types:

- `string`
- `number`
- `boolean`
- `null`
- `list`
- `object`
- `http_response`
- `datetime`
- `duration`
- `file_path`

Later data types:

- `process_result`
- `secret`
- `window_handle`
- `binary`

### 6.3 Variables

Variable scopes:

1. **Local variables**
   - Exist only during one script run.
   - MVP should support this.

2. **Persistent variables**
   - Stored between runs.
   - Add later.

3. **Runner variables**
   - Configured per runner (global variables accessable by all scripts).
   - Add later.

4. **Secret variables**
   - Sensitive values like API keys.
   - Add later with encryption.

Variable operations:

- Set variable
- Get variable
- Increment variable
- Append to list
- Set object field
- Get object field
- Clear variable

### 6.4 Expressions

Expressions are used in if/else, switch, loops, and action configs.

Boolean/comparison operations:

- `==`
- `!=`
- `>`
- `>=`
- `<`
- `<=`
- `and`
- `or`
- `not`
- `contains`
- `starts_with`
- `ends_with`
- `regex_match`
- `in_list`
- `is_null`
- `is_empty`

Math operations:

- `+`
- `-`
- `*`
- `/`
- `%`
- `round`
- `floor`
- `ceil`
- `min`
- `max`
- `random`

String operations:

- `trim`
- `lowercase`
- `uppercase`
- `replace`
- `split`
- `join`
- `substring`
- `format`

Object/JSON operations:

- Get field
- Set field
- JSON path
- Parse JSON
- Stringify JSON

### 6.5 Control Flow

MVP control flow:

- Block
- If
- Else
- Switch
- Local variables

Later control flow:

- Else-if
- Loop
- For each
- While
- Break
- Continue
- Return
- Try/catch
- Finally
- Retry
- Timeout block

### 6.6 Functions and Reusable Blocks

Later feature.

A function should support:

- Name
- Description
- Input parameters
- Return values
- Local variables
- Steps

Example concept:

```text
Function: Send Notification If Error
Inputs:
  - status: string
  - message: string
Output:
  - was_error: boolean
```

### 6.7 Error Handling

MVP:

- Stop script on error.
- Log error.
- Mark run as failed.

Later:

- Continue on error.
- Error branch.
- Retry action.
- Try/catch.
- Finally.
- Timeout per step.
- Timeout per script.

---

## 7. Capabilities

Capabilities describe what the runner can technically support.

Capabilities are not the same as permissions.

- Capability: Can this runner technically do this?
- Permission: Should this script be allowed to do this?

### 7.1 Trigger Capabilities

- `trigger.manual`
- `trigger.schedule`
- `trigger.hotkey`
- `trigger.file_watch`
- `trigger.webhook`
- `trigger.startup`
- `trigger.clipboard`
- `trigger.window_title`
- `trigger.process_started`

### 7.2 Action Capabilities

- `action.log`
- `action.delay`
- `action.notification`
- `action.http`
- `action.file`
- `action.process`
- `action.keyboard`
- `action.mouse`
- `action.clipboard`
- `action.window`
- `action.sound`
- `action.json`
- `action.text`

### 7.3 Runtime Capabilities

- `runtime.variables`
- `runtime.if`
- `runtime.switch`
- `runtime.loop`
- `runtime.function`
- `runtime.error_handling`
- `runtime.persistent_storage`
- `runtime.secrets`

### 7.4 Example Headless Linux Runner Capabilities

```json
{
  "mode": "headless",
  "platform": "linux",
  "capabilities": [
    "trigger.manual",
    "trigger.schedule",
    "trigger.file_watch",
    "trigger.webhook",
    "action.log",
    "action.delay",
    "action.http",
    "action.file",
    "action.process",
    "runtime.variables",
    "runtime.if",
    "runtime.switch"
  ]
}
```

### 7.5 Example Windows Desktop Agent Capabilities

```json
{
  "mode": "desktop_agent",
  "platform": "windows",
  "capabilities": [
    "trigger.manual",
    "trigger.schedule",
    "trigger.hotkey",
    "trigger.file_watch",
    "action.log",
    "action.delay",
    "action.http",
    "action.file",
    "action.process",
    "action.keyboard",
    "action.mouse",
    "action.clipboard",
    "action.window",
    "action.notification",
    "runtime.variables",
    "runtime.if",
    "runtime.switch",
    "runtime.loop"
  ]
}
```

---

## 8. Permissions and Risk Levels

### 8.1 Permission Categories

Low risk permissions:

- `log`
- `delay`
- `math`
- `text_transform`
- `json_parse`
- `set_local_variable`

Medium risk permissions:

- `show_notification`
- `http_request`
- `write_clipboard`
- `open_application`
- `keyboard_control`
- `mouse_control`
- `file_write_limited`

High risk permissions:

- `run_shell_command`
- `delete_file`
- `read_sensitive_file`
- `write_any_file`
- `download_file`
- `execute_downloaded_file`
- `read_clipboard`
- `startup_trigger`
- `webhook_public_bind`
- `process_kill`

### 8.2 Risk Levels

Use four risk levels:

1. `low`
2. `medium`
3. `high`
4. `dangerous`

Suggested mapping:

| Risk | Examples |
|---|---|
| Low | Log, delay, math, text transform, if/switch |
| Medium | HTTP request, notification, clipboard write |
| High | Keyboard/mouse control, file write, open app, startup trigger |
| Dangerous | Shell command, file deletion, execute downloaded file, read sensitive files |

### 8.3 Import Behavior by Risk

Low risk:

- Can import enabled if user chooses.

Medium risk:

- Show warning.
- Can import enabled after confirmation.

High risk:

- Import disabled by default.
- User can manually enable after reviewing.

Dangerous:

- Import disabled.
- Requires explicit advanced approval.
- Some categories disabled globally by default.

---

## 9. BaudBound Runner Design

The runner must be headless-first and CLI-first.

Desktop UI is optional and should be layered on top of the core runtime.

### 9.1 Runner Layers

```text
baudbound-core
- Script parser
- Package reader
- Schema validator
- Program validator
- Permission analyzer
- Capability checker
- Execution engine
- Logging abstractions

baudbound-storage
- SQLite storage
- Installed scripts
- Logs
- Settings
- Permissions
- Script hashes

baudbound-cli
- Import
- Validate
- Run
- Enable/disable
- Logs
- Config

baudbound-daemon
- Headless service mode
- Schedule triggers
- File watch triggers
- Webhook triggers

baudbound-agent
- Desktop user-session mode
- Hotkeys
- Keyboard/mouse/window/clipboard

baudbound-tray
- Optional tray UI
- Pause/resume
- Quick logs
- Import script
```

### 9.2 Runner Modes

#### CLI Mode

Used for manual execution and headless management.

Examples:

```bash
baudbound validate ./server-health-check.bbs
baudbound import ./server-health-check.bbs
baudbound list
baudbound run server-health-check
baudbound logs server-health-check
baudbound enable server-health-check
baudbound disable server-health-check
```

#### Headless Daemon/Service Mode

For servers, NAS machines, VPS machines, Docker-like server environments, and background automation.

Supports:

- Manual CLI runs
- Schedule triggers
- File watch triggers
- Webhook triggers
- HTTP actions
- File actions
- Process actions if allowed
- Logs
- Variables
- If/switch/loops

Does not require GUI.

Does not support normal desktop automation unless a desktop session/agent exists.

#### Desktop Agent Mode

For normal desktop automation.

Supports everything headless supports, plus:

- Global hotkeys
- Keyboard input
- Mouse input
- Window control
- Clipboard access
- Desktop notifications
- Tray icon
- Local approval dialogs

This should run in the logged-in user session.

#### Tray/Background Mode

For normal desktop users.

- Starts on login.
- Sits in the tray.
- Executes enabled scripts.
- Can pause all scripts.
- Can import scripts.
- Can show logs/settings.

---

## 10. Runner CLI Commands

Command name:

```bash
baudbound
```

Recommended command set:

```bash
baudbound --version
baudbound help

baudbound validate ./script.bbs
baudbound inspect ./script.bbs
baudbound import ./script.bbs
baudbound import ./script.bbs --disabled
baudbound import ./script.bbs --enable

baudbound list
baudbound show <script-id-or-name>
baudbound enable <script-id-or-name>
baudbound disable <script-id-or-name>
baudbound remove <script-id-or-name>

baudbound run <script-id-or-name>
baudbound stop <run-id>
baudbound stop-all

baudbound logs
baudbound logs <script-id-or-name>
baudbound logs --follow
baudbound logs --since 24h

baudbound config show
baudbound config path
baudbound config set <key> <value>
baudbound config edit

baudbound service install
baudbound service uninstall
baudbound service start
baudbound service stop
baudbound service status

baudbound safe-mode enable
baudbound safe-mode disable

baudbound backup create
baudbound backup restore <file>
```

---

## 11. Runner Configuration

Use a TOML config file.

File name:

```text
baudbound.toml
```

### 11.1 Example Headless Config

```toml
[runner]
name = "NutVault Runner"
mode = "headless"
start_paused = false

[storage]
database_path = "default"
script_package_dir = "default"
backup_dir = "default"

[execution]
max_concurrent_scripts = 4
default_script_timeout_seconds = 300
default_step_timeout_seconds = 30
same_script_policy = "ignore"

[triggers]
manual_enabled = true
schedules_enabled = true
file_watch_enabled = true
webhooks_enabled = false
hotkeys_enabled = false
startup_enabled = false

[network]
webhook_bind_ip = "127.0.0.1"
webhook_port = 43891
local_api_enabled = false
local_api_bind_ip = "127.0.0.1"
local_api_port = 43892

[security]
safe_mode = false
block_shell_commands = true
block_network_requests = false
block_file_delete = true
require_approval_for_risky_scripts = true
disable_imported_risky_scripts = true

[logs]
level = "info"
retention_days = 30
max_size_mb = 250
```

### 11.2 Example Desktop Agent Config

```toml
[runner]
name = "Main PC Runner"
mode = "desktop_agent"
start_paused = false

[desktop]
tray_enabled = true
notifications_enabled = true
keyboard_mouse_enabled = true
clipboard_enabled = true
window_control_enabled = true

[triggers]
manual_enabled = true
schedules_enabled = true
hotkeys_enabled = true
file_watch_enabled = true
webhooks_enabled = false

[security]
safe_mode = false
block_shell_commands = true
block_file_delete = true
require_approval_for_risky_scripts = true
disable_imported_risky_scripts = true
```

---

## 12. Runner Desktop UI

The runner must not contain a script editor.

Desktop UI should only manage installed scripts, settings, logs, and imports.

Pages:

- Installed Scripts
- Import Script
- Script Details
- Permissions
- Logs
- Settings
- About

### Installed Scripts Page

```text
[Enabled]  Work Startup
[Disabled] Server Health Check
[Enabled]  Discord Helper

Actions:
- Import
- Run
- Enable
- Disable
- Remove
- View logs
```

### Script Details Page

Show:

- Name
- Description
- Version
- Risk level
- Required capabilities
- Required permissions
- Triggers
- Last run
- Last error
- Package hash
- Program hash

### Settings Page

Sections:

- General
- Execution
- Security
- Triggers
- Network
- Storage
- Logs
- Desktop integration

---

## 13. Storage Design

Use SQLite.

Suggested tables:

```sql
installed_scripts
- id
- script_id
- name
- description
- version
- enabled
- risk_level
- package_hash
- program_hash
- manifest_json
- program_json
- permissions_json
- capabilities_json
- imported_at
- updated_at

script_permissions
- id
- script_id
- permission
- risk_level
- approved
- approved_hash
- approved_at

script_runs
- id
- script_id
- status
- started_at
- finished_at
- error_message

script_logs
- id
- run_id
- script_id
- level
- message
- created_at

runner_settings
- key
- value

persistent_variables
- id
- script_id
- name
- value_json
- updated_at

secrets
- id
- name
- encrypted_value
- created_at
- updated_at
```

MVP can skip:

- `persistent_variables`
- `secrets`

---

## 14. BaudBound Editor Design

The editor is a web app.

It can be used as:

1. Public hosted version.
2. Self-hosted Docker container.

It should not need a backend database for MVP.

### 14.1 Recommended Stack

- React or Svelte
- TypeScript
- Vite
- React Flow or Svelte Flow
- Zod or TypeBox for schema validation
- JSZip for `.bbs` export/import
- Docker image served by nginx or Caddy

### 14.2 Docker Example

```yaml
services:
  baudbound-editor:
    image: baudbound/editor:latest
    container_name: baudbound-editor
    restart: unless-stopped
    ports:
      - "8080:80"
```

### 14.3 Editor Pages

MVP pages:

- Home
- New Script
- Open `.bbs`
- Editor
- Export
- Documentation
- Examples/Templates

Later pages:

- Local browser library
- Script templates
- Block library
- Theme/settings

### 14.4 Editor MVP Features

- Visual script editor
- Manual trigger
- Variables
- If/else
- Switch
- Delay
- Log
- Notification
- HTTP request
- Export `.bbs`
- Import `.bbs` for editing
- Permission preview
- Capability preview
- Target runtime selector

### 14.5 Editor Advanced Features

- Loops
- Functions
- Sub-scripts
- Error branches
- Try/catch
- Retry blocks
- Persistent variable references
- Secret references
- JSON tools
- Regex tools
- File actions
- Desktop actions
- Script templates

### 14.6 Target Runtime Selector

The editor should ask what type of script the user is building.

Options:

- Generic headless
- Linux headless
- Windows headless/service
- macOS background
- Generic desktop
- Windows desktop
- Linux desktop
- macOS desktop

When user selects a headless target, editor should hide or warn for:

- Keyboard nodes
- Mouse nodes
- Window control nodes
- Hotkey trigger
- Desktop notification nodes if unsupported
- Clipboard nodes if unsupported

When user selects a desktop target, allow desktop nodes.

---

## 15. Import Flow in Runner

When user imports a `.bbs` file:

```text
1. User selects .bbs file
2. Runner opens package safely
3. Runner checks required files
4. Runner validates JSON schemas
5. Runner checks format version
6. Runner checks minimum runner version
7. Runner calculates package hash
8. Runner validates program AST
9. Runner calculates permissions
10. Runner calculates capabilities
11. Runner checks compatibility with current runner mode
12. Runner checks global security settings
13. Runner shows import summary
14. User chooses import disabled or import enabled
15. Runner stores script in SQLite
16. Runner registers triggers if enabled
```

### Compatible Import Example

```text
Script: Server Health Check
Format: BaudBound Script v1
Risk: Medium
Target: Generic headless

Required capabilities:
- Schedule trigger
- HTTP request
- JSON parse
- Log

Required permissions:
- Send HTTP requests
- Write logs

Compatibility:
✓ This runner supports all required capabilities.

Actions:
[Import disabled] [Import and enable] [Cancel]
```

### Incompatible Import Example

```text
Script: Discord Hotkey Reply
Risk: High

Required capabilities:
- Hotkey trigger
- Keyboard control
- Window control

Compatibility:
✗ This runner is running in headless mode.

Missing:
- Hotkey trigger
- Keyboard control
- Window control

Actions:
[Import disabled] [Cancel]
```

---

## 16. Execution Engine

The runner should not execute visual graph data directly.

Execution flow:

```text
program.json
  ↓
parse into AST
  ↓
validate AST
  ↓
compile execution plan
  ↓
run with runtime context
```

Runtime context should contain:

- Script ID
- Run ID
- Variables
- Permissions
- Logger
- Timeout settings
- Platform capabilities
- Trigger payload
- Cancellation token

Execution pipeline:

```text
Start script run
  ↓
Create runtime context
  ↓
Execute block
  ↓
Execute each step
  ↓
Evaluate expressions
  ↓
Branch if needed
  ↓
Log results
  ↓
Finish success/error
```

---

## 17. Triggers

### MVP Triggers

- `manual`
- `schedule`

### Near-Term Triggers

- `file_watch`
- `webhook`
- `startup`

### Desktop Triggers

- `hotkey`
- `clipboard_changed`
- `window_title_changed`
- `app_started`
- `idle_time`

---

## 18. Actions

### Core Actions

- `log`
- `delay`
- `set_variable`
- `show_notification`
- `http_request`
- `parse_json`
- `format_text`

### Headless Actions

- `read_file`
- `write_file`
- `append_file`
- `copy_file`
- `move_file`
- `run_process`
- `check_process`
- `send_webhook`

### Desktop Actions

- `press_key`
- `type_text`
- `move_mouse`
- `mouse_click`
- `set_clipboard`
- `get_clipboard`
- `focus_window`
- `get_active_window`
- `open_application`

### Dangerous Actions

- `run_shell_command`
- `delete_file`
- `download_file`
- `execute_file`
- `kill_process`
- `write_system_path`
- `read_sensitive_path`

Dangerous actions should be disabled or strongly gated by default.

---

## 19. Platform Support Plan

### Windows

Provide two modes:

1. Windows Service
   - Runs at boot.
   - Good for headless/server-style scripts.
   - Should not be used for keyboard/mouse/window automation.

2. User-session Agent
   - Runs on login.
   - Supports tray icon.
   - Supports keyboard/mouse/window automation.

Use cases:

```text
Desktop automation → user-session agent
Server-style automation → Windows service
```

### Linux

Provide:

1. systemd system service
   - Headless mode.
   - Good for servers/NAS.

2. systemd user service
   - Desktop-user mode.
   - Better for hotkeys/desktop actions.

Also support direct CLI:

```bash
baudbound start --headless
```

### macOS

Provide:

1. LaunchDaemon
   - Background/headless-style tasks.

2. LaunchAgent
   - User-session desktop tasks.

Desktop automation requires user approval for accessibility-style permissions.

### Docker

Docker is useful for the editor.

Docker runner mode only makes sense for headless/server scripts.

Docker runner can support:

- Manual
- Schedule
- Webhook
- HTTP
- File actions inside mounted volumes
- Logs

Docker runner should not attempt normal keyboard/mouse automation.

---

## 20. Versioning

Version these independently:

- BaudBound Editor version
- BaudBound Runner version
- `.bbs` package format version
- Script language version
- Node/action schema version

Example manifest fields:

```json
{
  "format_version": 1,
  "script_language_version": 1,
  "minimum_runner_version": "0.1.0"
}
```

Runner import rules:

- Unsupported format version: reject import.
- Runner version too old: reject or warn.
- Unknown node type: reject import.
- Unknown action type: reject import.
- Invalid action config: reject import.

---

## 21. Recommended Repository Structure

Start with a monorepo because the editor, runner, schemas, and examples are tightly connected.

```text
baudbound/
├─ apps/
│  ├─ editor/
│  ├─ runner-cli/
│  ├─ runner-desktop/
│  └─ docs/
├─ crates/
│  ├─ baudbound-core/
│  ├─ baudbound-script/
│  ├─ baudbound-runtime/
│  ├─ baudbound-storage/
│  ├─ baudbound-actions/
│  ├─ baudbound-triggers/
│  └─ baudbound-security/
├─ schemas/
│  ├─ manifest.schema.json
│  ├─ program.schema.json
│  ├─ permissions.schema.json
│  └─ capabilities.schema.json
└─ examples/
   ├─ hello-world.bbs
   ├─ server-health-check.bbs
   ├─ work-startup.bbs
   └─ simple-if-switch.bbs
```

---

## 22. Recommended Tech Stack

### Editor

- React or Svelte
- TypeScript
- Vite
- React Flow or Svelte Flow
- Zod or TypeBox
- JSZip
- nginx or Caddy Docker image

### Runner

- Rust
- serde
- serde_json
- tokio
- sqlx or rusqlite
- clap
- tracing
- zip crate
- notify crate
- reqwest
- scheduler/cron crate

### Desktop Features Later

- tray-icon
- global-hotkey
- enigo or platform-specific input libraries
- arboard for clipboard
- notify-rust or platform-specific notifications

---

## 23. MVP Plan

### Phase 1: Define `.bbs` Format

Deliverables:

- `manifest.json` schema
- `program.json` schema
- `permissions.json` schema
- `capabilities.json` schema
- Example `.bbs` packages
- Script language v1 specification

Script language v1 should support:

- Manual trigger
- Block
- Let variable
- If/else
- Switch
- Log
- Delay
- Show notification
- HTTP request

### Phase 2: Editor MVP

Deliverables:

- Web editor app
- Docker image
- Visual node editor
- Target runtime selector
- Permission preview
- Capability preview
- Export `.bbs`
- Import `.bbs` for editing

No accounts.
No backend.
No runner connection.

### Phase 3: Runner CLI MVP

Deliverables:

```bash
baudbound validate <file.bbs>
baudbound inspect <file.bbs>
baudbound import <file.bbs>
baudbound list
baudbound run <script>
baudbound logs
```

Runtime support:

- Manual trigger
- Variables
- If/else
- Switch
- Log
- Delay
- HTTP request

### Phase 4: Runner Storage and Logs

Deliverables:

- SQLite database
- Installed scripts table
- Run history
- Script logs
- Enable/disable scripts
- Config file

### Phase 5: Headless Daemon

Deliverables:

- `baudbound start --headless`
- Schedule trigger
- File watch trigger
- Service install command
- Linux systemd support

This makes BaudBound useful on servers.

### Phase 6: Security System

Deliverables:

- Permission analyzer
- Capability analyzer
- Risk levels
- Block dangerous actions
- Import warnings
- Script hash tracking
- Global allow/block config

### Phase 7: Desktop Agent

Deliverables:

- User-session agent
- Tray icon
- Hotkey trigger
- Keyboard action
- Mouse action
- Clipboard action
- Window/app actions
- Desktop notifications

### Phase 8: Advanced Visual Programming

Deliverables:

- Loops
- For-each
- While
- Break/continue
- Functions
- Return values
- Try/catch
- Retry blocks
- Persistent variables
- Secrets

---

## 24. First Example Scripts

Create these examples early:

### 1. Hello World

```text
Manual trigger → Log message
```

### 2. Server Health Check

```text
Schedule trigger
  → HTTP request
  → If status ok/warning/error
  → Log result
```

### 3. JSON API Monitor

```text
HTTP request
  → Parse JSON
  → Switch field value
  → Log or notify
```

### 4. File Watch Logger

```text
File changed
  → Log path
```

### 5. Work Startup

```text
Hotkey
  → Open apps
  → Type text
```

### 6. Clipboard Formatter

```text
Hotkey
  → Read clipboard
  → Transform text
  → Write clipboard
```

Start with examples 1 to 3 because they work headless.

---

## 25. Implementation Priorities

Start with headless-safe scripts first.

Initial focus:

1. `.bbs` package format
2. Script schema
3. Editor export/import
4. Runner validate/import
5. Runner CLI execution
6. Variables
7. If/else
8. Switch
9. Log/delay/HTTP actions
10. SQLite logs/storage

Do not start with keyboard/mouse automation. Add desktop automation after the runtime and script format are stable.

---

## 26. Final Direction

BaudBound should be built as:

```text
A local-first visual scripting automation platform.
```

Final structure:

```text
BaudBound Editor
- Web app
- Hosted by project or self-hosted with Docker
- Creates visual scripts
- Exports .bbs files
- No live runner connection
- No accounts required

BaudBound Runner
- Rust runtime
- Imports .bbs files
- Headless-first
- CLI-first
- Cross-platform
- Service/daemon capable
- Optional desktop agent/tray mode
- Validates and executes scripts safely
```

This design gives BaudBound:

- Lower security risk
- No complicated account system
- No LAN pairing system
- No browser-to-runner control channel
- Self-hostable editor
- Portable script files
- Headless support
- Desktop automation support later
- Clear separation between building and running scripts
