import { useState, useRef } from "react";
import {
  Play,
  Download,
  Upload,
  Settings,
  ChevronDown,
  ChevronRight,
  Zap,
  GitBranch,
  Clock,
  Globe,
  Terminal,
  Bell,
  FileText,
  MousePointer,
  Keyboard,
  Clipboard,
  Shield,
  Info,
  Search,
  X,
  Code,
  Database,
  Hash,
  AlertTriangle,
  CheckCircle2,
  Circle,
  Layers,
  Eye,
  MoreHorizontal,
  ChevronUp,
} from "lucide-react";

// ─── Types ───────────────────────────────────────────────────────────────────

type NodeKind = "trigger" | "action" | "control";
type RiskLevel = "low" | "medium" | "high" | "dangerous";

interface FlowNode {
  id: string;
  kind: NodeKind;
  label: string;
  x: number;
  y: number;
  outputs: string[];
  config: Record<string, string>;
  width: number;
  height: number;
}

interface FlowEdge {
  fromId: string;
  fromPort: string;
  toId: string;
}

interface PaletteItem {
  label: string;
  Icon: React.FC<{ size?: number; className?: string }>;
  risk: RiskLevel;
}

interface PaletteGroup {
  category: string;
  Icon: React.FC<{ size?: number; className?: string }>;
  items: PaletteItem[];
}

// ─── Constants ────────────────────────────────────────────────────────────────

const RISK_COLOR: Record<RiskLevel, string> = {
  low: "hsl(355, 70%, 50%)",
  medium: "#f5a623",
  high: "#e05c5c",
  dangerous: "#c22bff",
};

const KIND_COLOR: Record<NodeKind, string> = {
  trigger: "#5b8af5",
  control: "#a78bfa",
  action: "hsl(355, 70%, 50%)",
};

const PALETTE_GROUPS: PaletteGroup[] = [
  {
    category: "Triggers",
    Icon: Zap,
    items: [
      { label: "Manual", Icon: Play, risk: "low" },
      { label: "Schedule", Icon: Clock, risk: "low" },
      { label: "File Watch", Icon: FileText, risk: "low" },
      { label: "Webhook", Icon: Globe, risk: "medium" },
      { label: "Hotkey", Icon: Keyboard, risk: "medium" },
    ],
  },
  {
    category: "Control Flow",
    Icon: GitBranch,
    items: [
      { label: "If / Else", Icon: GitBranch, risk: "low" },
      { label: "Switch", Icon: Hash, risk: "low" },
      { label: "Set Variable", Icon: Database, risk: "low" },
      { label: "Loop", Icon: Clock, risk: "low" },
    ],
  },
  {
    category: "Actions",
    Icon: Terminal,
    items: [
      { label: "Log", Icon: Terminal, risk: "low" },
      { label: "Delay", Icon: Clock, risk: "low" },
      { label: "HTTP Request", Icon: Globe, risk: "medium" },
      { label: "Show Notification", Icon: Bell, risk: "medium" },
      { label: "Write File", Icon: FileText, risk: "high" },
      { label: "Run Process", Icon: Code, risk: "high" },
      { label: "Keyboard", Icon: Keyboard, risk: "high" },
      { label: "Mouse", Icon: MousePointer, risk: "high" },
      { label: "Clipboard", Icon: Clipboard, risk: "high" },
      { label: "Shell Command", Icon: Terminal, risk: "dangerous" },
    ],
  },
];

const TARGET_RUNTIMES = [
  "Generic Headless",
  "Linux Headless",
  "Windows Headless",
  "macOS Background",
  "Generic Desktop",
  "Windows Desktop",
  "Linux Desktop",
  "macOS Desktop",
];

// ─── Initial Graph ─────────────────────────────────────────────────────────

const INITIAL_NODES: FlowNode[] = [
  {
    id: "n0",
    kind: "trigger",
    label: "Manual Trigger",
    x: 60,
    y: 200,
    outputs: ["out"],
    config: {},
    width: 176,
    height: 64,
  },
  {
    id: "n1",
    kind: "action",
    label: "Set Variable",
    x: 300,
    y: 140,
    outputs: ["out"],
    config: { name: "status", value: "warning" },
    width: 176,
    height: 80,
  },
  {
    id: "n2",
    kind: "control",
    label: "If / Else",
    x: 544,
    y: 128,
    outputs: ["true", "false"],
    config: { condition: 'status == "ok"' },
    width: 176,
    height: 96,
  },
  {
    id: "n3",
    kind: "action",
    label: "Log",
    x: 796,
    y: 60,
    outputs: ["out"],
    config: { message: "Everything is okay." },
    width: 176,
    height: 72,
  },
  {
    id: "n4",
    kind: "action",
    label: "Show Notification",
    x: 796,
    y: 220,
    outputs: ["out"],
    config: { title: "Warning", message: "Status is warning." },
    width: 176,
    height: 80,
  },
];

const INITIAL_EDGES: FlowEdge[] = [
  { fromId: "n0", fromPort: "out", toId: "n1" },
  { fromId: "n1", fromPort: "out", toId: "n2" },
  { fromId: "n2", fromPort: "true", toId: "n3" },
  { fromId: "n2", fromPort: "false", toId: "n4" },
];

// ─── Permissions ─────────────────────────────────────────────────────────────

const PERMISSIONS = [
  { name: "set_local_variable", risk: "low" as RiskLevel },
  { name: "log", risk: "low" as RiskLevel },
  { name: "show_notification", risk: "medium" as RiskLevel },
];

// ─── Sub-components ───────────────────────────────────────────────────────────

function RiskBadge({ risk }: { risk: RiskLevel }) {
  const color = RISK_COLOR[risk];
  return (
    <span
      className="font-mono uppercase tracking-wider"
      style={{
        fontSize: "9px",
        color,
        background: `${color}18`,
        border: `1px solid ${color}30`,
        borderRadius: 2,
        padding: "1px 5px",
      }}
    >
      {risk}
    </span>
  );
}

// ─── Canvas node rendering ────────────────────────────────────────────────────

function CanvasNode({
  node,
  selected,
  onClick,
}: {
  node: FlowNode;
  selected: boolean;
  onClick: (e: React.MouseEvent) => void;
}) {
  const accent = KIND_COLOR[node.kind];
  const configEntries = Object.entries(node.config);

  return (
    <div
      onClick={(e) => { e.stopPropagation(); onClick(e); }}
      className="absolute select-none cursor-pointer"
      style={{
        left: node.x,
        top: node.y,
        width: node.width,
      }}
    >
      <div
        className="relative flex flex-col overflow-hidden"
        style={{
          background: "#131520",
          border: `1px solid ${selected ? accent : "#1e2130"}`,
          borderRadius: 4,
          boxShadow: selected
            ? `0 0 0 1px ${accent}40, 0 4px 24px rgba(0,0,0,0.5)`
            : "0 2px 12px rgba(0,0,0,0.4)",
          transition: "border-color 0.12s, box-shadow 0.12s",
        }}
      >
        {/* Header bar */}
        <div
          className="flex items-center gap-2 px-3 py-2"
          style={{
            borderBottom: "1px solid #1e2130",
            background: `${accent}10`,
          }}
        >
          <div
            className="rounded-sm"
            style={{ width: 6, height: 6, background: accent, borderRadius: 1 }}
          />
          <span
            className="font-medium truncate"
            style={{ fontSize: 11, color: "#d8dce8", fontFamily: "Outfit, sans-serif" }}
          >
            {node.label}
          </span>
          <span
            className="ml-auto font-mono uppercase"
            style={{ fontSize: 9, color: accent, opacity: 0.7 }}
          >
            {node.kind}
          </span>
        </div>

        {/* Config rows */}
        {configEntries.length > 0 && (
          <div className="flex flex-col gap-0" style={{ padding: "6px 8px" }}>
            {configEntries.map(([k, v]) => (
              <div key={k} className="flex items-start gap-1" style={{ fontSize: 10 }}>
                <span style={{ color: "#4b5563", fontFamily: "JetBrains Mono, monospace", minWidth: 40 }}>
                  {k}
                </span>
                <span
                  className="truncate"
                  style={{ color: "#9ca3af", fontFamily: "JetBrains Mono, monospace" }}
                >
                  {v}
                </span>
              </div>
            ))}
          </div>
        )}

        {/* Ports */}
        {/* Input port dot */}
        {node.kind !== "trigger" && (
          <div
            className="absolute"
            style={{
              left: -5,
              top: "50%",
              transform: "translateY(-50%)",
              width: 10,
              height: 10,
              background: "#1a1c26",
              border: "2px solid #3d4259",
              borderRadius: "50%",
            }}
          />
        )}

        {/* Output port dots */}
        {node.outputs.map((port, i) => {
          const total = node.outputs.length;
          const topPct = total === 1 ? 50 : 25 + i * 50;
          return (
            <div
              key={port}
              className="absolute flex items-center gap-1"
              style={{ right: -5, top: `${topPct}%`, transform: "translateY(-50%)" }}
            >
              {total > 1 && (
                <span
                  style={{
                    fontSize: 8,
                    fontFamily: "JetBrains Mono, monospace",
                    color: port === "true" ? "hsl(355, 70%, 50%)" : "#e05c5c",
                    marginRight: 2,
                    userSelect: "none",
                  }}
                >
                  {port}
                </span>
              )}
              <div
                style={{
                  width: 10,
                  height: 10,
                  background: accent,
                  border: `2px solid ${accent}60`,
                  borderRadius: "50%",
                  opacity: 0.9,
                }}
              />
            </div>
          );
        })}
      </div>
    </div>
  );
}

// ─── SVG Edges ────────────────────────────────────────────────────────────────

function EdgePath({
  fromNode,
  fromPort,
  toNode,
}: {
  fromNode: FlowNode;
  fromPort: string;
  toNode: FlowNode;
}) {
  const accent = KIND_COLOR[fromNode.kind];

  const outIdx = fromNode.outputs.indexOf(fromPort);
  const total = fromNode.outputs.length;
  const outYPct = total === 1 ? 0.5 : 0.25 + outIdx * 0.5;

  const x1 = fromNode.x + fromNode.width;
  const y1 = fromNode.y + fromNode.height * outYPct;
  const x2 = toNode.x;
  const y2 = toNode.y + toNode.height * 0.5;

  const dx = Math.abs(x2 - x1) * 0.5;
  const d = `M${x1},${y1} C${x1 + dx},${y1} ${x2 - dx},${y2} ${x2},${y2}`;

  const color = fromPort === "true" ? "hsl(355, 70%, 50%)" : fromPort === "false" ? "#e05c5c" : accent;

  return (
    <path
      d={d}
      fill="none"
      stroke={color}
      strokeWidth={1.5}
      strokeOpacity={0.55}
      strokeDasharray={fromPort === "false" ? "4 3" : undefined}
    />
  );
}

// ─── Main App ─────────────────────────────────────────────────────────────────

export default function App() {
  const [nodes] = useState<FlowNode[]>(INITIAL_NODES);
  const [edges] = useState<FlowEdge[]>(INITIAL_EDGES);
  const [selectedNodeId, setSelectedNodeId] = useState<string | null>("n2");
  const [searchQuery, setSearchQuery] = useState("");
  const [expandedGroups, setExpandedGroups] = useState<Record<string, boolean>>({
    Triggers: true,
    "Control Flow": true,
    Actions: true,
  });
  const [activeTab, setActiveTab] = useState<"properties" | "permissions" | "output">("properties");
  const [targetRuntime, setTargetRuntime] = useState("Generic Headless");
  const [scriptName, setScriptName] = useState("server-health-check");
  const [showRuntimeDropdown, setShowRuntimeDropdown] = useState(false);
  const [bottomPanelOpen, setBottomPanelOpen] = useState(true);

  const canvasRef = useRef<HTMLDivElement>(null);

  const selectedNode = nodes.find((n) => n.id === selectedNodeId) ?? null;

  const toggleGroup = (cat: string) => {
    setExpandedGroups((prev) => ({ ...prev, [cat]: !prev[cat] }));
  };

  const filteredGroups = PALETTE_GROUPS.map((g) => ({
    ...g,
    items: g.items.filter((item) =>
      item.label.toLowerCase().includes(searchQuery.toLowerCase())
    ),
  })).filter((g) => g.items.length > 0);

  // Canvas SVG bounding box
  const canvasW = 1040;
  const canvasH = 400;

  const isDesktopTarget = targetRuntime.toLowerCase().includes("desktop");

  return (
    <div
      className="flex flex-col"
      style={{
        height: "100vh",
        background: "#0b0c10",
        fontFamily: "Outfit, sans-serif",
        color: "#d8dce8",
        overflow: "hidden",
      }}
    >
      {/* ── Top Bar ────────────────────────────────────────────────────────── */}
      <header
        className="flex items-center gap-3 px-4 shrink-0"
        style={{
          height: 44,
          background: "#0e0f14",
          borderBottom: "1px solid #1e2130",
          zIndex: 20,
        }}
      >
        {/* Logo */}
        <div className="flex items-center gap-2 mr-2">
          <div
            className="flex items-center justify-center font-mono font-semibold"
            style={{
              width: 26,
              height: 26,
              background: "hsl(355, 70%, 50%)",
              color: "#0b0c10",
              borderRadius: 4,
              fontSize: 11,
              letterSpacing: "-0.5px",
            }}
          >
            BB
          </div>
          <span className="font-semibold" style={{ fontSize: 13, letterSpacing: "-0.3px" }}>
            BaudBound <span style={{ color: "#6b7484" }}>Editor</span>
          </span>
        </div>

        <div style={{ width: 1, height: 20, background: "#1e2130" }} />

        {/* Script name */}
        <input
          value={scriptName}
          onChange={(e) => setScriptName(e.target.value)}
          className="font-mono"
          style={{
            background: "transparent",
            border: "none",
            outline: "none",
            color: "#d8dce8",
            fontSize: 12,
            width: 200,
          }}
        />

        <div style={{ width: 1, height: 20, background: "#1e2130" }} />

        {/* Runtime selector */}
        <div className="relative">
          <button
            onClick={() => setShowRuntimeDropdown((v) => !v)}
            className="flex items-center gap-2 px-3 py-1 rounded"
            style={{
              background: "#1a1c26",
              border: "1px solid #1e2130",
              color: "#d8dce8",
              fontSize: 11,
              cursor: "pointer",
              fontFamily: "Outfit, sans-serif",
            }}
          >
            <Layers size={12} style={{ color: "#6b7484" }} />
            <span>{targetRuntime}</span>
            <ChevronDown size={11} style={{ color: "#6b7484" }} />
          </button>
          {showRuntimeDropdown && (
            <div
              className="absolute top-full mt-1 z-50 flex flex-col overflow-hidden"
              style={{
                background: "#15171f",
                border: "1px solid #1e2130",
                borderRadius: 4,
                minWidth: 180,
                boxShadow: "0 8px 32px rgba(0,0,0,0.6)",
              }}
            >
              {TARGET_RUNTIMES.map((rt) => (
                <button
                  key={rt}
                  onClick={() => {
                    setTargetRuntime(rt);
                    setShowRuntimeDropdown(false);
                  }}
                  className="flex items-center gap-2 px-3 py-2 text-left"
                  style={{
                    fontSize: 11,
                    color: rt === targetRuntime ? "hsl(355, 70%, 50%)" : "#d8dce8",
                    background: rt === targetRuntime ? "#1a1c26" : "transparent",
                    border: "none",
                    cursor: "pointer",
                    fontFamily: "Outfit, sans-serif",
                  }}
                >
                  {rt === targetRuntime && <CheckCircle2 size={10} />}
                  {rt !== targetRuntime && <Circle size={10} style={{ opacity: 0.3 }} />}
                  {rt}
                </button>
              ))}
            </div>
          )}
        </div>

        {!isDesktopTarget && (
          <span
            className="font-mono px-2 py-0.5"
            style={{
              fontSize: 9,
              color: "#f5a623",
              background: "#f5a62318",
              border: "1px solid #f5a62330",
              borderRadius: 2,
              letterSpacing: "0.05em",
            }}
          >
            HEADLESS
          </span>
        )}
        {isDesktopTarget && (
          <span
            className="font-mono px-2 py-0.5"
            style={{
              fontSize: 9,
              color: "#5b8af5",
              background: "#5b8af518",
              border: "1px solid #5b8af530",
              borderRadius: 2,
              letterSpacing: "0.05em",
            }}
          >
            DESKTOP
          </span>
        )}

        <div className="flex-1" />

        {/* Actions */}
        <div className="flex items-center gap-2">
          <TopBarButton Icon={Upload} label="Import .bbs" />
          <TopBarButton Icon={Download} label="Export .bbs" primary />
          <button
            className="flex items-center justify-center"
            style={{
              width: 28,
              height: 28,
              background: "transparent",
              border: "1px solid #1e2130",
              borderRadius: 4,
              color: "#6b7484",
              cursor: "pointer",
            }}
          >
            <Settings size={13} />
          </button>
        </div>
      </header>

      {/* ── Body ─────────────────────────────────────────────────────────── */}
      <div className="flex flex-1 overflow-hidden">

        {/* ── Left Sidebar: Block Palette ─────────────────────────────────── */}
        <aside
          className="flex flex-col shrink-0"
          style={{
            width: 220,
            background: "#0e0f14",
            borderRight: "1px solid #1e2130",
            overflow: "hidden",
          }}
        >
          {/* Search */}
          <div className="px-3 py-2 shrink-0" style={{ borderBottom: "1px solid #1e2130" }}>
            <div
              className="flex items-center gap-2 px-2 py-1.5"
              style={{
                background: "#1a1c26",
                border: "1px solid #1e2130",
                borderRadius: 3,
              }}
            >
              <Search size={11} style={{ color: "#6b7484" }} />
              <input
                placeholder="Search blocks..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                style={{
                  background: "transparent",
                  border: "none",
                  outline: "none",
                  color: "#d8dce8",
                  fontSize: 11,
                  width: "100%",
                  fontFamily: "Outfit, sans-serif",
                }}
              />
              {searchQuery && (
                <button onClick={() => setSearchQuery("")} style={{ color: "#6b7484", cursor: "pointer", background: "none", border: "none" }}>
                  <X size={10} />
                </button>
              )}
            </div>
          </div>

          <div className="flex-1 overflow-y-auto" style={{ padding: "4px 0" }}>
            {filteredGroups.map((group) => (
              <div key={group.category}>
                <button
                  onClick={() => toggleGroup(group.category)}
                  className="flex items-center gap-2 w-full px-3 py-2"
                  style={{
                    background: "transparent",
                    border: "none",
                    cursor: "pointer",
                    color: "#6b7484",
                    fontSize: 10,
                    letterSpacing: "0.07em",
                    fontFamily: "JetBrains Mono, monospace",
                    textTransform: "uppercase",
                  }}
                >
                  {expandedGroups[group.category] ? (
                    <ChevronDown size={10} />
                  ) : (
                    <ChevronRight size={10} />
                  )}
                  <group.Icon size={10} />
                  {group.category}
                </button>

                {expandedGroups[group.category] && (
                  <div className="flex flex-col" style={{ paddingBottom: 4 }}>
                    {group.items.map((item) => (
                      <PaletteBlock key={item.label} item={item} />
                    ))}
                  </div>
                )}
              </div>
            ))}
          </div>
        </aside>

        {/* ── Canvas ────────────────────────────────────────────────────────── */}
        <main
          className="flex-1 flex flex-col overflow-hidden"
          style={{ position: "relative" }}
          onClick={() => {
            setSelectedNodeId(null);
            setShowRuntimeDropdown(false);
          }}
        >
          {/* Canvas area */}
          <div
            ref={canvasRef}
            className="flex-1 overflow-auto relative"
            style={{
              background: "#0b0c10",
              backgroundImage: `radial-gradient(circle, #1e2130 1px, transparent 1px)`,
              backgroundSize: "24px 24px",
              cursor: "default",
            }}
          >
            <div style={{ position: "relative", width: canvasW, height: canvasH, minWidth: "100%", minHeight: "100%" }}>
              {/* SVG edges */}
              <svg
                style={{
                  position: "absolute",
                  top: 0,
                  left: 0,
                  width: canvasW,
                  height: canvasH,
                  pointerEvents: "none",
                  overflow: "visible",
                }}
              >
                {edges.map((edge, i) => {
                  const fromNode = nodes.find((n) => n.id === edge.fromId);
                  const toNode = nodes.find((n) => n.id === edge.toId);
                  if (!fromNode || !toNode) return null;
                  return (
                    <EdgePath
                      key={i}
                      fromNode={fromNode}
                      fromPort={edge.fromPort}
                      toNode={toNode}
                    />
                  );
                })}
              </svg>

              {/* Nodes */}
              {nodes.map((node) => (
                <CanvasNode
                  key={node.id}
                  node={node}
                  selected={selectedNodeId === node.id}
                  onClick={(e) => {
                    setSelectedNodeId(node.id);
                  }}
                />
              ))}
            </div>
          </div>

          {/* Bottom output panel */}
          {bottomPanelOpen && (
            <div
              style={{
                height: 140,
                background: "#0e0f14",
                borderTop: "1px solid #1e2130",
                display: "flex",
                flexDirection: "column",
                shrink: 0,
              }}
            >
              <div
                className="flex items-center gap-3 px-4 shrink-0"
                style={{ height: 32, borderBottom: "1px solid #1e2130" }}
              >
                <span style={{ fontSize: 10, color: "#6b7484", fontFamily: "JetBrains Mono, monospace", textTransform: "uppercase", letterSpacing: "0.07em" }}>
                  Output
                </span>
                <div className="flex-1" />
                <button
                  onClick={() => setBottomPanelOpen(false)}
                  style={{ background: "none", border: "none", color: "#6b7484", cursor: "pointer" }}
                >
                  <ChevronDown size={12} />
                </button>
              </div>
              <div className="flex-1 overflow-y-auto p-3" style={{ fontFamily: "JetBrains Mono, monospace", fontSize: 11, color: "#6b7484" }}>
                <div><span style={{ color: "hsl(355, 70%, 50%)" }}>[info]</span> Script loaded: server-health-check</div>
                <div><span style={{ color: "hsl(355, 70%, 50%)" }}>[info]</span> Target runtime: {targetRuntime}</div>
                <div><span style={{ color: "hsl(355, 70%, 50%)" }}>[info]</span> Permissions calculated: {PERMISSIONS.length} required</div>
                <div><span style={{ color: "#f5a623" }}>[warn]</span> show_notification requires medium risk approval on import</div>
                <div><span style={{ color: "hsl(355, 70%, 50%)" }}>[info]</span> Script is valid. Ready to export.</div>
              </div>
            </div>
          )}

          {!bottomPanelOpen && (
            <button
              onClick={() => setBottomPanelOpen(true)}
              className="flex items-center gap-2 px-4"
              style={{
                height: 28,
                background: "#0e0f14",
                borderTop: "1px solid #1e2130",
                border: "none",
                cursor: "pointer",
                color: "#6b7484",
                fontSize: 10,
                fontFamily: "JetBrains Mono, monospace",
                textTransform: "uppercase",
                letterSpacing: "0.07em",
              }}
            >
              <ChevronUp size={10} />
              Output
            </button>
          )}
        </main>

        {/* ── Right Sidebar: Properties ───────────────────────────────────── */}
        <aside
          className="flex flex-col shrink-0"
          style={{
            width: 256,
            background: "#0e0f14",
            borderLeft: "1px solid #1e2130",
            overflow: "hidden",
          }}
        >
          {/* Tabs */}
          <div
            className="flex shrink-0"
            style={{ borderBottom: "1px solid #1e2130" }}
          >
            {(["properties", "permissions", "output"] as const).map((tab) => (
              <button
                key={tab}
                onClick={() => setActiveTab(tab)}
                className="flex-1 py-2 capitalize"
                style={{
                  background: activeTab === tab ? "#1a1c26" : "transparent",
                  border: "none",
                  borderBottom: activeTab === tab ? "2px solid hsl(355, 70%, 50%)" : "2px solid transparent",
                  color: activeTab === tab ? "#d8dce8" : "#6b7484",
                  fontSize: 10,
                  cursor: "pointer",
                  fontFamily: "JetBrains Mono, monospace",
                  textTransform: "uppercase",
                  letterSpacing: "0.07em",
                  marginBottom: -1,
                }}
              >
                {tab}
              </button>
            ))}
          </div>

          <div className="flex-1 overflow-y-auto">
            {activeTab === "properties" && (
              <PropertiesPanel node={selectedNode} />
            )}
            {activeTab === "permissions" && (
              <PermissionsPanel />
            )}
            {activeTab === "output" && (
              <OutputPanel targetRuntime={targetRuntime} />
            )}
          </div>
        </aside>
      </div>

      {/* ── Status Bar ───────────────────────────────────────────────────── */}
      <footer
        className="flex items-center gap-4 px-4 shrink-0"
        style={{
          height: 24,
          background: "#0a0b0f",
          borderTop: "1px solid #1a1c24",
          fontFamily: "JetBrains Mono, monospace",
          fontSize: 10,
          color: "#4b5563",
        }}
      >
        <span style={{ color: "hsl(355, 70%, 50%)" }}>● ready</span>
        <span>{nodes.length} nodes</span>
        <span>{edges.length} edges</span>
        <span>format v1</span>
        <span>lang v1</span>
        <div className="flex-1" />
        <span>BaudBound Editor 0.1.0</span>
      </footer>
    </div>
  );
}

// ─── Sub-components ───────────────────────────────────────────────────────────

function TopBarButton({
  Icon,
  label,
  primary,
}: {
  Icon: React.FC<{ size?: number }>;
  label: string;
  primary?: boolean;
}) {
  return (
    <button
      className="flex items-center gap-1.5 px-3 py-1 rounded"
      style={{
        background: primary ? "hsl(355, 70%, 50%)" : "#1a1c26",
        border: `1px solid ${primary ? "hsl(355, 70%, 50%)" : "#1e2130"}`,
        color: primary ? "#0b0c10" : "#d8dce8",
        fontSize: 11,
        cursor: "pointer",
        fontFamily: "Outfit, sans-serif",
        fontWeight: 500,
      }}
    >
      <Icon size={12} />
      {label}
    </button>
  );
}

function PaletteBlock({ item }: { item: PaletteItem }) {
  const color = RISK_COLOR[item.risk];
  return (
    <div
      className="flex items-center gap-2 mx-2 px-2 py-1.5 rounded cursor-grab"
      style={{
        fontSize: 11,
        color: "#b0b5c8",
        border: "1px solid transparent",
        borderRadius: 3,
        transition: "background 0.1s, border-color 0.1s",
      }}
      onMouseEnter={(e) => {
        (e.currentTarget as HTMLDivElement).style.background = "#1a1c26";
        (e.currentTarget as HTMLDivElement).style.borderColor = "#1e2130";
      }}
      onMouseLeave={(e) => {
        (e.currentTarget as HTMLDivElement).style.background = "transparent";
        (e.currentTarget as HTMLDivElement).style.borderColor = "transparent";
      }}
    >
      <item.Icon size={11} style={{ color: "#6b7484" }} />
      <span className="flex-1" style={{ fontFamily: "Outfit, sans-serif" }}>{item.label}</span>
      <div style={{ width: 5, height: 5, borderRadius: "50%", background: color, opacity: 0.7 }} />
    </div>
  );
}

function PropertiesPanel({ node }: { node: FlowNode | null }) {
  if (!node) {
    return (
      <div
        className="flex flex-col items-center justify-center h-full gap-2"
        style={{ color: "#4b5563" }}
      >
        <MousePointer size={24} style={{ opacity: 0.3 }} />
        <p style={{ fontSize: 11, fontFamily: "JetBrains Mono, monospace" }}>
          Select a node
        </p>
      </div>
    );
  }

  const accent = KIND_COLOR[node.kind];

  return (
    <div className="flex flex-col gap-0">
      {/* Node header */}
      <div
        className="flex items-center gap-2 px-4 py-3"
        style={{ borderBottom: "1px solid #1e2130" }}
      >
        <div
          style={{
            width: 8,
            height: 8,
            background: accent,
            borderRadius: 1,
          }}
        />
        <div>
          <div style={{ fontSize: 12, fontWeight: 500 }}>{node.label}</div>
          <div style={{ fontSize: 10, color: "#6b7484", fontFamily: "JetBrains Mono, monospace" }}>
            {node.kind} · id:{node.id}
          </div>
        </div>
      </div>

      {/* Config fields */}
      {Object.entries(node.config).length > 0 && (
        <div className="flex flex-col gap-3 px-4 py-3" style={{ borderBottom: "1px solid #1e2130" }}>
          <span style={{ fontSize: 9, color: "#6b7484", fontFamily: "JetBrains Mono, monospace", textTransform: "uppercase", letterSpacing: "0.07em" }}>
            Configuration
          </span>
          {Object.entries(node.config).map(([key, val]) => (
            <div key={key} className="flex flex-col gap-1">
              <label style={{ fontSize: 10, color: "#6b7484", fontFamily: "JetBrains Mono, monospace" }}>
                {key}
              </label>
              <input
                defaultValue={val}
                style={{
                  background: "#1a1c26",
                  border: "1px solid #1e2130",
                  borderRadius: 3,
                  padding: "4px 8px",
                  color: "#d8dce8",
                  fontSize: 11,
                  outline: "none",
                  fontFamily: "JetBrains Mono, monospace",
                  width: "100%",
                  boxSizing: "border-box",
                }}
                onFocus={(e) => (e.target.style.borderColor = "hsl(355, 70%, 50%)")}
                onBlur={(e) => (e.target.style.borderColor = "#1e2130")}
              />
            </div>
          ))}
        </div>
      )}

      {/* Outputs */}
      <div className="flex flex-col gap-2 px-4 py-3" style={{ borderBottom: "1px solid #1e2130" }}>
        <span style={{ fontSize: 9, color: "#6b7484", fontFamily: "JetBrains Mono, monospace", textTransform: "uppercase", letterSpacing: "0.07em" }}>
          Ports
        </span>
        {node.kind !== "trigger" && (
          <div className="flex items-center gap-2">
            <div style={{ width: 8, height: 8, borderRadius: "50%", background: "#1a1c26", border: "1.5px solid #3d4259" }} />
            <span style={{ fontSize: 11, color: "#6b7484" }}>input</span>
          </div>
        )}
        {node.outputs.map((port) => (
          <div key={port} className="flex items-center gap-2">
            <div style={{ width: 8, height: 8, borderRadius: "50%", background: accent }} />
            <span style={{ fontSize: 11, color: "#d8dce8", fontFamily: "JetBrains Mono, monospace" }}>{port}</span>
          </div>
        ))}
      </div>

      {/* Node kind info */}
      <div className="px-4 py-3">
        <div
          className="flex items-start gap-2 px-3 py-2 rounded"
          style={{ background: "#1a1c26", border: "1px solid #1e2130" }}
        >
          <Info size={11} style={{ color: "#6b7484", marginTop: 1 }} />
          <p style={{ fontSize: 10, color: "#6b7484", lineHeight: 1.5 }}>
            {node.kind === "trigger" && "Entry point. Defines when the script starts."}
            {node.kind === "action" && "Performs an operation with optional side-effects."}
            {node.kind === "control" && "Branches or loops execution flow."}
          </p>
        </div>
      </div>
    </div>
  );
}

function PermissionsPanel() {
  return (
    <div className="flex flex-col gap-0">
      <div className="px-4 py-3" style={{ borderBottom: "1px solid #1e2130" }}>
        <span style={{ fontSize: 9, color: "#6b7484", fontFamily: "JetBrains Mono, monospace", textTransform: "uppercase", letterSpacing: "0.07em" }}>
          Required Permissions
        </span>
      </div>

      <div className="flex flex-col gap-0">
        {PERMISSIONS.map((perm) => (
          <div
            key={perm.name}
            className="flex items-center justify-between px-4 py-2"
            style={{ borderBottom: "1px solid #1e2130" }}
          >
            <span style={{ fontSize: 11, fontFamily: "JetBrains Mono, monospace", color: "#b0b5c8" }}>
              {perm.name}
            </span>
            <RiskBadge risk={perm.risk} />
          </div>
        ))}
      </div>

      {/* Risk summary */}
      <div className="px-4 py-3" style={{ borderBottom: "1px solid #1e2130" }}>
        <span style={{ fontSize: 9, color: "#6b7484", fontFamily: "JetBrains Mono, monospace", textTransform: "uppercase", letterSpacing: "0.07em" }}>
          Calculated Risk
        </span>
        <div
          className="flex items-center gap-2 mt-2 px-3 py-2 rounded"
          style={{ background: "#f5a62310", border: "1px solid #f5a62330", borderRadius: 3 }}
        >
          <AlertTriangle size={12} style={{ color: "#f5a623" }} />
          <span style={{ fontSize: 11, color: "#f5a623", fontFamily: "Outfit, sans-serif" }}>
            Medium risk — show_notification
          </span>
        </div>
      </div>

      {/* Capabilities */}
      <div className="px-4 py-3">
        <span style={{ fontSize: 9, color: "#6b7484", fontFamily: "JetBrains Mono, monospace", textTransform: "uppercase", letterSpacing: "0.07em" }}>
          Required Capabilities
        </span>
        <div className="flex flex-col gap-1 mt-2">
          {["trigger.manual", "action.log", "action.notification", "runtime.variables", "runtime.if"].map((cap) => (
            <div key={cap} className="flex items-center gap-2">
              <CheckCircle2 size={10} style={{ color: "hsl(355, 70%, 50%)" }} />
              <span style={{ fontSize: 10, fontFamily: "JetBrains Mono, monospace", color: "#6b7484" }}>
                {cap}
              </span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

function OutputPanel({ targetRuntime }: { targetRuntime: string }) {
  const isDesktop = targetRuntime.toLowerCase().includes("desktop");

  return (
    <div className="flex flex-col gap-0">
      <div className="px-4 py-3" style={{ borderBottom: "1px solid #1e2130" }}>
        <span style={{ fontSize: 9, color: "#6b7484", fontFamily: "JetBrains Mono, monospace", textTransform: "uppercase", letterSpacing: "0.07em" }}>
          Export Preview
        </span>
      </div>

      <div className="px-4 py-3 flex flex-col gap-2" style={{ borderBottom: "1px solid #1e2130" }}>
        <div className="flex justify-between items-center">
          <span style={{ fontSize: 10, color: "#6b7484" }}>File name</span>
          <span style={{ fontSize: 10, fontFamily: "JetBrains Mono, monospace", color: "#d8dce8" }}>
            server-health-check.bbs
          </span>
        </div>
        <div className="flex justify-between items-center">
          <span style={{ fontSize: 10, color: "#6b7484" }}>Format</span>
          <span style={{ fontSize: 10, fontFamily: "JetBrains Mono, monospace", color: "#d8dce8" }}>v1</span>
        </div>
        <div className="flex justify-between items-center">
          <span style={{ fontSize: 10, color: "#6b7484" }}>Language</span>
          <span style={{ fontSize: 10, fontFamily: "JetBrains Mono, monospace", color: "#d8dce8" }}>v1</span>
        </div>
        <div className="flex justify-between items-center">
          <span style={{ fontSize: 10, color: "#6b7484" }}>Min runner</span>
          <span style={{ fontSize: 10, fontFamily: "JetBrains Mono, monospace", color: "#d8dce8" }}>0.1.0</span>
        </div>
        <div className="flex justify-between items-center">
          <span style={{ fontSize: 10, color: "#6b7484" }}>Target</span>
          <span style={{ fontSize: 10, fontFamily: "JetBrains Mono, monospace", color: "#d8dce8" }}>
            {targetRuntime}
          </span>
        </div>
      </div>

      {/* Package structure */}
      <div className="px-4 py-3" style={{ borderBottom: "1px solid #1e2130" }}>
        <span style={{ fontSize: 9, color: "#6b7484", fontFamily: "JetBrains Mono, monospace", textTransform: "uppercase", letterSpacing: "0.07em" }}>
          .bbs Contents
        </span>
        <div className="flex flex-col gap-1 mt-2">
          {["manifest.json", "program.json", "permissions.json", "capabilities.json", "README.md"].map((f) => (
            <div key={f} className="flex items-center gap-2">
              <FileText size={9} style={{ color: "#6b7484" }} />
              <span style={{ fontSize: 10, fontFamily: "JetBrains Mono, monospace", color: "#6b7484" }}>
                {f}
              </span>
            </div>
          ))}
        </div>
      </div>

      {isDesktop && (
        <div
          className="mx-4 my-3 flex items-start gap-2 px-3 py-2"
          style={{ background: "#5b8af518", border: "1px solid #5b8af530", borderRadius: 3 }}
        >
          <Eye size={11} style={{ color: "#5b8af5", marginTop: 1 }} />
          <p style={{ fontSize: 10, color: "#5b8af5", lineHeight: 1.5 }}>
            Desktop capabilities detected. Script will require desktop agent mode.
          </p>
        </div>
      )}

      <div className="px-4 py-3">
        <button
          className="flex items-center justify-center gap-2 w-full py-2 rounded"
          style={{
            background: "hsl(355, 70%, 50%)",
            border: "none",
            color: "#0b0c10",
            fontSize: 12,
            fontWeight: 600,
            cursor: "pointer",
            fontFamily: "Outfit, sans-serif",
            borderRadius: 4,
          }}
        >
          <Download size={13} />
          Export .bbs
        </button>
      </div>
    </div>
  );
}
